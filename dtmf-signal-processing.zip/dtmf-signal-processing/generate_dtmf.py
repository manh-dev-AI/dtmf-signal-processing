import numpy as np
from scipy.io.wavfile import write

low_freqs  = [697, 770, 852, 941]
high_freqs = [1209, 1336, 1477, 1633]
keys = [['1','2','3','A'],
        ['4','5','6','B'],
        ['7','8','9','C'],
        ['*','0','#','D']]

def get_freqs(key):
    for i in range(4):
        for j in range(4):
            if keys[i][j] == key:
                return low_freqs[i], high_freqs[j]
    return None, None

fs = 8000
tone_duration = 0.5
pause_duration = 0.3

digits = input("Enter DTMF sequence (e.g., 123#0): ").strip().upper()
t = np.linspace(0, tone_duration, int(fs * tone_duration), endpoint=False)

signal = np.array([], dtype=float)
for d in digits:
    f1, f2 = get_freqs(d)
    if f1 is None:
        print(f"Skipping invalid key: {d}")
        continue
    tone = np.sin(2*np.pi*f1*t) + np.sin(2*np.pi*f2*t)
    silence = np.zeros(int(fs * pause_duration))
    signal = np.concatenate((signal, tone, silence))

signal = signal / np.max(np.abs(signal))
write("samples/dtmf_input.wav", fs, (signal * 32767).astype(np.int16))
print("✅ File saved as samples/dtmf_input.wav")
