# 🎵 DTMF Signal Processing

A Python project for recognizing DTMF (Dual-Tone Multi-Frequency) tones using digital signal processing techniques.

## 📁 Project Structure
```
dtmf-signal-processing/
├── main.py
├── generate_dtmf.py
├── requirements.txt
├── README.md
├── report/
├── samples/
└── notebooks/
```

## 🚀 How to Run
1️⃣ Install dependencies  
```bash
pip install -r requirements.txt
```

2️⃣ Generate DTMF audio  
```bash
python generate_dtmf.py
```

3️⃣ Detect tones  
```bash
python main.py samples/dtmf_input.wav
```

## 📚 Report
Vietnamese report available in `report/Bao_cao_DTMF_DSP.docx`.
