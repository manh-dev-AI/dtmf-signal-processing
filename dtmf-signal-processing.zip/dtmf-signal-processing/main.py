import numpy as np
import matplotlib.pyplot as plt
from scipy.io import wavfile
from scipy.signal import find_peaks
import sys

def nearest_freq(f, freq_list):
    return freq_list[np.argmin([abs(f - ff) for ff in freq_list])]

def detect_dtmf(signal, fs):
    fft_vals = np.fft.fft(signal)
    fft_freqs = np.fft.fftfreq(len(signal), 1/fs)
    half = len(fft_vals)//2
    fft_mag = np.abs(fft_vals[:half])
    freqs = fft_freqs[:half]

    valid = (freqs > 600) & (freqs < 1700)
    fft_mag = fft_mag[valid]
    freqs = freqs[valid]

    peaks, _ = find_peaks(fft_mag, height=np.max(fft_mag)*0.3)
    if len(peaks) < 2:
        return None

    peak_freqs = freqs[peaks]
    peak_mags = fft_mag[peaks]
    top_indices = np.argsort(peak_mags)[-2:]
    f1, f2 = sorted(peak_freqs[top_indices])
    return f1, f2

def main(filename):
    fs, data = wavfile.read(filename)
    if data.ndim > 1:
        data = data[:, 0]
    signal = data / np.max(np.abs(data))

    segment_duration = 0.5
    pause_duration = 0.3
    segment_samples = int(segment_duration * fs)
    pause_samples = int(pause_duration * fs)
    step = segment_samples + pause_samples

    low_freqs  = [697, 770, 852, 941]
    high_freqs = [1209, 1336, 1477, 1633]
    keys = [['1','2','3','A'],
            ['4','5','6','B'],
            ['7','8','9','C'],
            ['*','0','#','D']]

    detected = []
    start = 0
    while start + segment_samples <= len(signal):
        seg = signal[start:start+segment_samples]
        result = detect_dtmf(seg, fs)
        if result:
            f1, f2 = result
            f_low = nearest_freq(f1, low_freqs)
            f_high = nearest_freq(f2, high_freqs)
            row = low_freqs.index(f_low)
            col = high_freqs.index(f_high)
            detected.append(keys[row][col])
        start += step

    print("Detected sequence:", " ".join(detected))

    t = np.arange(len(signal)) / fs
    plt.figure(figsize=(10,4))
    plt.plot(t, signal)
    plt.title(f"Audio Signal: {filename}")
    plt.xlabel("Time (s)")
    plt.ylabel("Amplitude")
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python main.py <wav_filename>")
    else:
        main(sys.argv[1])
